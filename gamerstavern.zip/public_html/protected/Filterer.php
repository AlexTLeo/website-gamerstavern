<?php

/**
 * Class Filterer: used to filter out words from input compared to a specified text file dictionary
 * the input file must contain one word per line and nothing more, e.g. :
 *
 * dog
 * cat
 * dolphin
 *
 */
class Filterer {
    private $whitelist;

    function __construct($whitelistDictionary) {
        $this->whitelist = $whitelistDictionary;
    }

    /**
     * Replace words that are in the blacklist
     * @param $unfiltered
     */
    function filterBlacklist($unfiltered) {
        $fileUrl = __DIR__ . $this->whitelist;
        $replaceWith = " ***** ";
        $filtered = trim($unfiltered);
        $blacklist = file($fileUrl);

        foreach($blacklist as $line) {
            $line = preg_replace("/(\W)+/","", $line);
            $filtered = str_ireplace("$line", $replaceWith, $filtered);
        }

        // Fully filtered
        return $filtered;
    }
}