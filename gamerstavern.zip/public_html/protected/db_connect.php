<?php
$conn['address'] = 'localhost';
$conn['user'] = 'S4633433';
$conn['password'] = '27664*0.437lysirius';
$conn['db'] = 'S4633433';

// Connection
$mysqli = new mysqli($conn['address'], $conn['user'], $conn['password'], $conn['db']);