<?php
// Pre-checks
require('control_header.php');
global $mysqli;

// Object to log operations
require('../Logger.php');
$logger = new Logger('articles.log', '/logs/');

checkConnection($mysqli, $logger);

checkLoggedIn("Failed article upload attempt: must be logged in");


// Make sure only writers can insert
if (!isset($_SESSION['is_writer']) || $_SESSION['is_writer'] != 1) {
    $logger->log('Non-writer attempt to upload article by session_id: ' . session_id());
    $return_data['error'] = "Failed article upload attempt: you are not a writer";
    exit(json_encode($return_data));
}

// Checking if all required fields have been sent (banner image is checked below)
$required_fields = array('title', 'author', 'category', 'body');

foreach ($required_fields as $field) {
    if (!isset($_POST["$field"]) || empty($_POST["$field"])) {
        $logger->log('Failed article upload due to missing ' . "$field" . ' field');
        $return_data['error'] = "Article submission failed: <strong>$field</strong> cannot be empty";
        exit(json_encode($return_data));
    }
}

// Get input
$title = $_POST['title'];
$author = $_POST['author'];
$category = $_POST['category'];
$body = $_POST['body'];
$fk_user_id = $_SESSION['user_id'];
$posted_date = date('Y-m-d h:i:s', time());

// Trims
$title = trim($title);
$author = trim($author);
$category = trim($category);
$body = trim($body);

// Sanitize and validate
$title = filter_var($title, FILTER_SANITIZE_STRING);
$author = filter_var($author, FILTER_SANITIZE_STRING);
$category = filter_var($category, FILTER_SANITIZE_STRING);
$fk_user_id = filter_var($fk_user_id, FILTER_VALIDATE_INT);

// Dealing with banner image upload
if (isset($_FILES['banner_image']['tmp_name'])) {
    // Sanitize the name
    $_FILES['banner_image']['name'] = filter_var(trim($_FILES['banner_image']['name']), FILTER_SANITIZE_STRING);

    // Check valid format
    $image_ext = strtolower(pathinfo($_FILES['banner_image']['tmp_name'], PATHINFO_EXTENSION));
    if ((exif_imagetype($_FILES['banner_image']['tmp_name']) == IMAGETYPE_PNG) ||
        (exif_imagetype($_FILES['banner_image']['tmp_name']) == IMAGETYPE_JPEG)) {

        // Image name is randomized
        $image_name = uniqid() . '.' . $image_ext;

        // Directory for image upload
        $target_dir = "../../img/blog/";
        $target_file = $target_dir . $image_name;

        // Check file size and upload picture to server
        if ($_FILES['banner_image']['size'] > MAX_IMG_SIZE_BYTES) {
            $logger->log("Failed article upload attempt by author $author: uploaded image exceeds 5MB" .
                MAX_IMG_SIZE_BYTES/1000000 . 'MB');
            $return_data['error'] = 'Submission failed: <strong>banner image</strong> must not exceed <strong>' .
                MAX_IMG_SIZE_BYTES/1000000 . 'MB</strong>';
            exit(json_encode($return_data));
        } else {
            move_uploaded_file($_FILES['banner_image']['tmp_name'], $target_file);
        }
    } else {
        $logger->log("Failed article upload attempt by author $author: invalid image type (not jpeg/png)");
        $return_data['error'] = 'Submission failed: <strong>banner image</strong> must be either <strong>JPEG/JPG</strong> or <strong>PNG</strong>';
        exit(json_encode($return_data));
    }
} else {
    $logger->log("Failed article upload attempt by author $author: missing banner image");
    $return_data['error'] = 'Submission failed: missing <strong>banner image</strong>';
    exit(json_encode($return_data));
}

// Preparing and executing query
$query = "INSERT INTO `article` (
                    article_id,
                    author,
                    `body`,
                    title,
                    banner_image_url,
                    posted_date,
                    fk_user_id,
                    category
              ) VALUES (NULL, ?, ?, ?, ?, ?, ?, ?)";

if ($stmt = $mysqli->prepare($query)) {
    $stmt->bind_param("sssssis", $author, $body, $title, $image_name, $posted_date, $fk_user_id, $category);

    if ($stmt->execute()) {
        // If insert successful
        $logger->log('Successful article submission by author ' . $author);

        $mysqli->close();
        $stmt->close();

        $return_data['success'] = '<strong>Success</strong>! Article posted';
        exit(json_encode($return_data));
    } else {
        // If insert fails
        $logger->log("Failed article submission attempt by author $author: ($mysqli->errno) $mysqli->error");

        $mysqli->close();
        $stmt->close();

        $return_data['error'] = '<strong>Failure Code 001</strong>! Please contact support';
        exit(json_encode($return_data));
    }
} else {
    // If prepare() failed
    $logger->log("Query error by author $author" .
        ': (' . $mysqli->errno . ') ' . $mysqli->error);

    $return_data['error'] = '<strong>Failure Code 002</strong>! Please contact support';
    exit(json_encode($return_data));
}
