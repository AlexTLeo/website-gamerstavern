<?php
$return_articles = array();
// Pre-checks
require('control_header.php');
global $mysqli;

// Object to log operations
require('../Logger.php');
$logger = new Logger('articles.log', '/logs/');

// Object to purify article HTML in output
require_once('../htmlpurifier/library/HTMLPurifier.auto.php');
$config = HTMLPurifier_Config::createDefault();
$purifier = new HTMLPurifier($config);

checkConnection($mysqli, $logger);

// Sanitizing and validating search input
if (isset($_GET['search']) && !empty($_GET['search'])) {
    $search = "%" . filter_var($_GET['search'], FILTER_SANITIZE_STRING) . "%";
} else {
    $search = "%%";
}

// Flag to enable search by category ONLY
if (isset($_GET['catonly']) && $_GET['catonly'] === "true") {
    $categoryOnly = true;
} else {
    $categoryOnly = false;
}

// Flag to enable search by article ID
if (isset($_GET['article_id']) && !empty($_GET['article_id'])) {
    $searchByID = true;
    $article_id = filter_var($_GET['article_id'], FILTER_VALIDATE_INT);
} else {
    $searchByID = false;
}

// Getting offset of rows to load (pagination)
if (isset($_GET['offset']) && !empty($_GET['offset'])) {
    $offset = filter_var(trim($_GET['offset']), FILTER_VALIDATE_INT);
} else {
    $offset = 0;
}

// Preparing and executing query
if ($categoryOnly) {
    $query = "SELECT article_id, author, `body`, title, banner_image_url, posted_date, category
              FROM article
              WHERE category LIKE ?
              ORDER BY posted_date DESC
              LIMIT ?, 5";

    if ($stmt = $mysqli->prepare($query)) {
        $stmt->bind_param("si", $search, $offset);
    } else {
        $stmt->close();
        $mysqli->close();

        exit("Article load failure: please contact support");
    }
} else if ($searchByID) {
    $query = "SELECT article_id, author, `body`, title, banner_image_url, posted_date, category
              FROM article
              WHERE article_id=?
              LIMIT 1";

    if ($stmt = $mysqli->prepare($query)) {
        $stmt->bind_param("i", $article_id);
    } else {
        $stmt->close();
        $mysqli->close();

        exit("Article load failure: please contact support");
    }
} else {
    $query = "SELECT article_id, author, `body`, title, banner_image_url, posted_date, category
              FROM article
              WHERE author LIKE ? OR
                    `body` LIKE ? OR
                    title LIKE ? OR
                    category LIKE ?
              ORDER BY posted_date DESC
              LIMIT ?, 5";

    if ($stmt = $mysqli->prepare($query)) {
        $stmt->bind_param("ssssi", $search, $search, $search, $search, $offset);
    } else {
        $stmt->close();
        $mysqli->close();

        exit("Article load failure: please contact support");
    }
}

$stmt->execute();
$stmt->bind_result($article_id, $author, $body, $title, $banner_image_url, $posted_date, $category);
$stmt->store_result();

while ($stmt->fetch()) {
    // Escaping output
    $author = $purifier->purify($author);
    $author = htmlspecialchars($author);
    $body = $purifier->purify($body);
//    $body = htmlspecialchars($body);
    $title = $purifier->purify($title);
    $title = htmlspecialchars($title);
    $category = $purifier->purify($category);
    $category = htmlspecialchars($category);
    $article_id = filter_var($article_id, FILTER_VALIDATE_INT); // just in case!

    // No time value, just date
    $posted_date = strtotime($posted_date);
    $posted_date = date("d-m-Y", $posted_date);

    // Array of arrays (articles)
    array_push($return_articles, array(
        'article_id' => $article_id,
        'author' => $author,
        'body' => $body,
        'title' => $title,
        'banner_image_url' => $banner_image_url,
        'posted_date' => $posted_date,
        'category' => $category
    ));
}

$stmt->free_result();
$stmt->close();
$mysqli->close();

// Output is ready
exit(json_encode($return_articles));