<?php
// Pre-checks
require('control_header.php');
global $mysqli;

// Object to log operations
require('../Logger.php');
$logger = new Logger('registrations.log', '/logs/');

checkConnection($mysqli, $logger);

// Checking if all required fields have been sent
$required_fields = array('firstname', 'lastname', 'email', 'pass', 'confirm');

foreach ($required_fields as $field) {
    if (!isset($_POST["$field"]) || empty($_POST["$field"])) {
        $logger->log('Failed registration attempt due to missing ' . "$field" . ' field');
        $return_data['error'] = "Registration failed: <strong>$field</strong> cannot be empty";
        exit(json_encode($return_data));
    }
}

// Sanitize and validate input
$firstname = $_POST['firstname'];
$lastname = $_POST['lastname'];
$email = $_POST['email'];
$password = $_POST['pass'];
$confirm_password = $_POST['confirm'];

// Checking name to be literal
if (!ctype_alpha(str_replace(array(' ', "'"), '', $firstname)) ||
    !ctype_alpha(str_replace(array(' ', "'"), '', $lastname))) {
    $logger->log("Failed registration attempt with email " . $_POST['email'] . " : non literal name ($firstname $lastname)");
    $return_data['error'] = "Registration failed: <strong>first/last name</strong> must be literal";
    exit(json_encode($return_data));
}

// Checking password length
if (strlen($password) < 8) {
    $logger->log("Failed registration attempt with email " . $_POST['email'] . " : invalid password");
    $return_data['error'] = "Registration failed: <strong>password</strong> must be at least <b>8</b> characters long";
    exit(json_encode($return_data));
}

// Trims
$firstname = trim($firstname);
$lastname = trim($lastname);
$email = trim($email);
$password = trim($password);
$confirm_password = trim($confirm_password);

$email = filter_var($email, FILTER_SANITIZE_EMAIL);
$email = filter_var($email, FILTER_VALIDATE_EMAIL);

$hashed_password = password_hash($password, PASSWORD_DEFAULT);

// If email validator "deleted" the email (because it was invalid)
if (!isset($email) || empty($email)) {
    $logger->log('Failed registration attempt: invalid email: ' . $_POST['email']);
    $return_data['error'] = "Registration failed: <strong>email</strong> invalid";
    exit(json_encode($return_data));
}

// If a profile picture was selected
if (isset($_FILES['profilepic']['tmp_name'])) {
    // Sanitize the name
    $_FILES['profilepic']['name'] = filter_var(trim($_FILES['profilepic']['name']), FILTER_SANITIZE_STRING);

    // Check valid format
    $profilepic_ext = strtolower(pathinfo($_FILES['profilepic']['tmp_name'], PATHINFO_EXTENSION));
    if ((exif_imagetype($_FILES['profilepic']['tmp_name']) == IMAGETYPE_PNG) ||
        (exif_imagetype($_FILES['profilepic']['tmp_name']) == IMAGETYPE_JPEG)) {

        // Picture name is randomized
        $profilepic_name = uniqid() . '.' . $profilepic_ext;

        // Directory for image upload
        $target_dir = "../../img/users/profile_pictures/";
        $target_file = $target_dir . $profilepic_name;

        // Check file size and upload picture to server
        if ($_FILES['profilepic']['size'] > MAX_IMG_SIZE_BYTES) {
            $logger->log('Failed registration attempt with email ' . $_POST['email'] . ' : uploaded image exceeds' .
                MAX_IMG_SIZE_BYTES/1000000 . 'MB');
            $return_data['error'] = 'Registration failed: <strong>profile image</strong> must not exceed <strong>' .
                MAX_IMG_SIZE_BYTES/1000000 . 'MB</strong>';
            exit(json_encode($return_data));
        } else {
            // File OK: upload!
            move_uploaded_file($_FILES['profilepic']['tmp_name'], $target_file);
        }
    } else {
        $logger->log('Failed registration attempt with email ' . $_POST['email'] . ' : invalid image type (not jpg/png)');
        $return_data['error'] = 'Registration failed: <strong>profile image</strong> must be either <strong>JPEG/JPG</strong> or <strong>PNG</strong>';
        exit(json_encode($return_data));
    }
} else {
    // If user did not upload an image, set default
    $profilepic_name = 'profile-default.png';
}

// Check if password and password confirmation fields are identical
if (password_verify($confirm_password, $hashed_password)) {
    // Preparing and executing query
    $query = "INSERT INTO `user` (
                    user_id,
                    `name`,
                    surname,
                    email,
                    `password`,
                    is_writer,
                    profile_image_url
              ) VALUES (NULL, ?, ?, ?, ?, 0, ?)";

    if ($stmt = $mysqli->prepare($query)) {
        $stmt->bind_param("sssss", $firstname, $lastname, $email, $hashed_password, $profilepic_name);

        if ($stmt->execute()) {
            // If insert successful
            $logger->log('Successful registration with email ' . $_POST['email']);

            $mysqli->close();
            $stmt->close();

            $return_data['success'] = '<strong>Welcome</strong> to the tavern! Please log in';
            exit(json_encode($return_data));
        } else {
            // If insert fails
            $logger->log('Failed registration attempt with email ' . $_POST['email'] . ' : email already exists');

            $mysqli->close();
            $stmt->close();

            $return_data['error'] = 'Registration failed: <strong>email</strong> already exists';
            exit(json_encode($return_data));
        }
    } else {
        // If prepare() failed
        $logger->log('Query error with email ' . $_POST['email'] .
            ': (' . $mysqli->errno . ') ' . $mysqli->error);

        $return_data['error'] = 'Registration failed: please try again later';
        exit(json_encode($return_data));
    }

} else {
    // If password and confirm_password are not equals
    $logger->log('Failed registration attempt with email ' . $_POST['email'] . ' : password and confirmation do not match');

    $mysqli->close();

    $return_data['error'] = 'Registration failed: <strong>password</strong> and <strong>confirmation</strong> must match';
    exit(json_encode($return_data));
}
