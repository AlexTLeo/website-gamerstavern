<?php
// Pre-checks
require('control_header.php');
global $mysqli;

// Object to log operations
require('../Logger.php');
$logger = new Logger('profile_updates.log', '/logs/');

checkConnection($mysqli, $logger);

checkLoggedIn("Failed profile update attempt: must be logged in");

// Checking if all required fields have been sent
$required_fields = array('firstname', 'lastname', 'email');

foreach ($required_fields as $field) {
    if (!isset($_POST["$field"]) || empty($_POST["$field"])) {
        $logger->log('Failed profile update attempt due to missing ' . "$field" . ' field');
        $return_data['error'] = "Profile update failed: <strong>$field</strong> cannot be empty";
        exit(json_encode($return_data));
    }
}

// Getting user input and id
$user_id = $_SESSION['user_id'];
$firstname = $_POST['firstname'];
$lastname = $_POST['lastname'];
$email = $_POST['email'];
$email_original = $email;

// Name must be literal and contain at most spaces and apostrophes
if (!ctype_alpha(str_replace(array(' ', "'"), '', $firstname)) ||
    !ctype_alpha(str_replace(array(' ', "'"), '', $lastname))) {
    $logger->log("Failed profile update attempt by email $email: invalid name ($firstname $lastname)");
    $return_data['error'] = "Profile update failed: <strong>first/last name</strong> must be literal and may contain spaces and apostrophes";
    exit(json_encode($return_data));
}

// Trims
$firstname = trim($firstname);
$lastname = trim($lastname);
$email = trim($email);

// Sanitize and validate input
$user_id = filter_var($user_id, FILTER_VALIDATE_INT);
$email = filter_var($email, FILTER_SANITIZE_EMAIL);
$email = filter_var($email, FILTER_VALIDATE_EMAIL);

// If email validator changed the email in any way (because it was invalid)
if ($email != $email_original) {
    $logger->log('Failed profile update attempt: invalid email: ' . $_POST['email']);
    $return_data['error'] = "Profile update failed: <strong>email</strong> invalid";
    exit(json_encode($return_data));
}

// If a profile picture is uploaded
if (isset($_FILES['profilepic']['tmp_name'])) {
    // Sanitize the name
    $_FILES['profilepic']['name'] = filter_var(trim($_FILES['profilepic']['name']), FILTER_SANITIZE_STRING);

    // Check valid format (jpeg, png)
    $profilepic_ext = strtolower(pathinfo($_FILES['profilepic']['tmp_name'], PATHINFO_EXTENSION));
    if ((exif_imagetype($_FILES['profilepic']['tmp_name']) == IMAGETYPE_PNG) ||
        (exif_imagetype($_FILES['profilepic']['tmp_name']) == IMAGETYPE_JPEG)) {

        // Image name is randomized
        $profilepic_name = uniqid() . '.' . $profilepic_ext;

        // Directory for image upload
        $target_dir = "../../img/users/profile_pictures/";
        $target_file = $target_dir . $profilepic_name;

        // Check file size and upload picture to server
        if ($_FILES['profilepic']['size'] > MAX_IMG_SIZE_BYTES) {
            $logger->log('Failed profile update attempt with email ' . $_POST['email'] . ' : uploaded image exceeds' .
                MAX_IMG_SIZE_BYTES/1000000 . 'MB');
            $return_data['error'] = 'Profile update failed: <strong>profile image</strong> must not exceed <strong>' .
                MAX_IMG_SIZE_BYTES/1000000 . 'MB</strong>';
            exit(json_encode($return_data));
        } else {
            // File OK: upload!
            move_uploaded_file($_FILES['profilepic']['tmp_name'], $target_file);
        }
    } else {
        // Invalid file format (not jpeg/png)
        $logger->log('Failed profile update attempt with email ' . $_POST['email'] . ' : invalid image type (not jpg/png)');
        $return_data['error'] = 'Profile update failed: <strong>profile image</strong> must be either <strong>JPEG/JPG</strong> or <strong>PNG</strong>';
        exit(json_encode($return_data));
    }
} else {
    // If user did not upload an image, don't change image
    $profilepic_name = $_POST['profilepic'];
}

// Prepare query
$query = "UPDATE `user` set `name`=?, surname=?, email=?, profile_image_url=? where user_id=? LIMIT 1";

// Preparing and executing query
if ($stmt = $mysqli->prepare($query)) {
    $stmt->bind_param('ssssi', $firstname, $lastname, $email, $profilepic_name, $user_id);

    if ($stmt->execute()) {
        // Successful update: send profilepic data back to client
        $return_data['profilepic'] = $profilepic_name;

        // Update SESSION information
        $_SESSION['name'] = $firstname;
        $_SESSION['surname'] = $lastname;

        $logger->log('Successful profile update by email ' . $email);
        $return_data['success'] = 'Profile successfully updated';
        exit(json_encode($return_data));
    } else {
        // Query error
        $mysqli->close();
        $stmt->close();

        $logger->log('Failed profile update by email ' . $_SESSION['email'] . " : ($mysqli->errno) $mysqli->error");
        $return_data['error'] = 'Cannot update profile: please try again later';
        exit(json_encode($return_data));
    }
} else {
    // SQL syntax error
    $mysqli->close();

    $logger->log('Failed profile update by email ' . $_SESSION['email'] . " : ($mysqli->errno) $mysqli->error");
    $return_data['error'] = 'Cannot update profile: please try again later';
    exit(json_encode($return_data));
}