<?php
/**
 * Configures and checks database connection
 * Sets HTTPS header (as JSON)
 * Checks session
 */

require('../db_connect.php');
define('MAX_IMG_SIZE_BYTES', 2000000);

// Data will be returned as JSON
header('Content-Type: application/json');
$return_data = array();

// If session not started, session_start
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

/**
 * Make sure the connection did not fail
 * @param $mysqli mysqli object
 * @param $logger Logger object
 */
function checkConnection($mysqli, $logger) {
    if ($mysqli->connect_error) {
        $logger->log('Database connection error: (' . $mysqli->connect_errno . ') ' . $mysqli->connect_error);
        $return_data['error'] = 'Failed to connect to the database';
        exit(json_encode($return_data));
    }
}

/**
 * Make sure request comes from an authenticated client
 * @param $error_message string
 */
function checkLoggedIn($error_message) {
    // Make sure is logged in
    if (isset($_SESSION)) {
        if (!isset($_SESSION['logged_in']) || !$_SESSION['logged_in'] ||
            empty($_SESSION['logged_in']) || !isset($_SESSION['user_id']) ||
            empty($_SESSION['user_id'])) {
            $return_data['error'] = $error_message;
            exit(json_encode($return_data));
        }
    } else {
        $return_data['error'] = 'Failed operation: invalid session';
        exit(json_encode($return_data));
    }
}