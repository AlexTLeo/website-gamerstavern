<?php
// Pre-checks
require('control_header.php');
global $mysqli;

// Object to log operations
require('../Logger.php');
$logger = new Logger('articles.log', '/logs/');

checkConnection($mysqli, $logger);

checkLoggedIn("Failed article deletion attempt: must be logged in");

// Make sure only writers can delete
if (!$_SESSION['is_writer'] || $_SESSION['is_writer'] != 1) {
    $logger->log('Non-writer attempt to delete article by session_id: ' . session_id());
    $return_data['error'] = "Failed article deletion attempt: you are not a writer";
    exit(json_encode($return_data));
}

// Get input
$article_id = $_POST['article_id'];
$author = $_SESSION['name'] . ' ' . $_SESSION['surname'];

// Sanitize and validate
$article_id = filter_var($article_id, FILTER_VALIDATE_INT);

// Preparing and executing query
$query = "DELETE FROM article
          WHERE article_id=?
          LIMIT 1";

if ($stmt = $mysqli->prepare($query)) {
    $stmt->bind_param("i", $article_id);

    if ($stmt->execute()) {
        // If delete successful
        $logger->log('Successful article deletion by author ' . $author);

        $mysqli->close();
        $stmt->close();

        $return_data['success'] = '<strong>Success</strong>! Article deleted';
        exit(json_encode($return_data));
    } else {
        // If delete fails
        $logger->log("Failed article deletion attempt by author $author: ($mysqli->errno) $mysqli->error");

        $mysqli->close();
        $stmt->close();

        $return_data['error'] = '<strong>Failure Code 003</strong>! Please contact support';
        exit(json_encode($return_data));
    }
} else {
    // If prepare() failed
    $logger->log("Query error by author $author" .
        ': (' . $mysqli->errno . ') ' . $mysqli->error);

    $return_data['error'] = '<strong>Failure Code 004</strong>! Please contact support';
    exit(json_encode($return_data));
}
