<?php
// Pre-checks
require('control_header.php');
global $mysqli;

// Object to log operations
require('../Logger.php');
$logger = new Logger('comments.log', '/logs/');

checkConnection($mysqli, $logger);

checkLoggedIn("Failed comment deletion attempt: must be logged in");

// Get input
$user_id = $_SESSION['user_id'];
$comment_poster_id = $_POST['comment_poster_id'];
$comment_id = $_POST['comment_id'];
$article_id = $_POST['article_id'];

// Validate as integers just in case
$user_id = filter_var($user_id, FILTER_VALIDATE_INT);
$comment_poster_id = filter_var($comment_poster_id, FILTER_VALIDATE_INT);
$comment_id = filter_var($comment_id, FILTER_VALIDATE_INT);
$article_id = filter_var($article_id, FILTER_VALIDATE_INT);

// Make sure users can only delete their own comments OR delete attempt is by moderator/writer
if ($_SESSION['user_id'] != $comment_poster_id &&
    (isset($_SESSION['is_writer']) && $_SESSION['is_writer'] != 1)) {
    $logger->log("Failed comment deletion attempt by user id $user_id on article id $article_id: " .
        "($mysqli->connect_errno) $mysqli->connect_error");
    $return_data['error'] = "Failed comment deletion attempt: this comment doesn't belong to you. " .
                            "Here at GamersTavern we believe in freedom of speech";
    exit(json_encode($return_data));
}

// Preparing and executing query
$query = "DELETE FROM `comment`
          WHERE comment_id=?
          LIMIT 1";

if ($stmt = $mysqli->prepare($query)) {
    $stmt->bind_param("i", $comment_id);

    if ($stmt->execute()) {
        // If delete successful
        $logger->log("Comment with id $comment_id deleted by user_id $user_id from article id $article_id");

        $mysqli->close();
        $stmt->close();

        $return_data['success'] = '<strong>Success</strong>! Comment deleted';
        exit(json_encode($return_data));
    } else {
        // If delete fails
        $logger->log("Failed comment deletion attempt on comment id $comment_id by user_id $user_id " .
            "on article id $article_id: ($mysqli->errno) $mysqli->error");

        $mysqli->close();
        $stmt->close();

        $return_data['error'] = '<strong>Failure Code 030</strong>! Please contact support';
        exit(json_encode($return_data));
    }
} else {
    // If prepare() failed
    $logger->log("Failed comment deletion attempt on comment id $comment_id by user_id $user_id on $article_id: " .
        "($mysqli->errno) $mysqli->error");

    $return_data['error'] = '<strong>Failure Code 040</strong>! Please contact support';
    exit(json_encode($return_data));
}
