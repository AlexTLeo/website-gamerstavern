<?php
// Pre-checks
require('control_header.php');
global $mysqli;

// Object to log operations
require('../Logger.php');
$logger = new Logger('profile_updates.log', '/logs/');

checkConnection($mysqli, $logger);

checkLoggedIn("Cannot load profile: must be logged in");

// Getting input
$user_id = $_SESSION['user_id'];

// Validate
$user_id = filter_var($user_id, FILTER_VALIDATE_INT);

// Prepare query
$query = "SELECT `name`, surname, email, profile_image_url from `user` where user_id=? LIMIT 1";

// Preparing and executing query
if ($stmt = $mysqli->prepare($query)) {
    $stmt->bind_param('i', $user_id);

    if ($stmt->execute()) {
        $stmt->bind_result($firstname, $lastname, $email, $profile_image_url);
        $stmt->store_result();

        if ($stmt->fetch()) {
            // Successful fetch, store profile, sanitize and return them to client
            $firstname = htmlspecialchars($firstname);
            $lastname = htmlspecialchars($lastname);
            $email = htmlspecialchars($email);

            $return_data['firstname'] = $firstname;
            $return_data['lastname'] = $lastname;
            $return_data['email'] = $email;
            $return_data['profilepic_url'] = $profile_image_url;

            $return_data['success'] = 'Profile successfully loaded';
            exit(json_encode($return_data));
        } else {
            // Failed fetch
            $logger->log("Cannot load profile for user_id $user_id: ($mysqli->errno) $mysqli->error");

            $mysqli->close();
            $stmt->close();

            $return_data['error'] = 'Cannot load profile: please contact support';
            exit(json_encode($return_data));
        }
    } else {
        // Failed query
        $logger->log("Cannot load profile for user_id $user_id: ($mysqli->errno) $mysqli->error");

        $mysqli->close();
        $stmt->close();

        $return_data['error'] = 'Cannot load profile: please contact support';
        exit(json_encode($return_data));
    }
} else {
    // Query syntax error
    $logger->log("Cannot load profile for user_id $user_id: ($mysqli->errno) $mysqli->error");

    $mysqli->close();

    $return_data['error'] = 'Cannot load profile: please contact support';
    exit(json_encode($return_data));
}
