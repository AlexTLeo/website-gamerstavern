<?php
// Pre-checks
require('control_header.php');
global $mysqli;

// Object to log operations
require('../Logger.php');
$logger = new Logger('comments.log', '/logs/');

checkConnection($mysqli, $logger);

checkLoggedIn("Failed comment posting attempt: must be logged in");

// Checking if all required fields have been sent (banner image is checked below)
$required_fields = array('article_id', 'text');

foreach ($required_fields as $field) {
    if (!isset($_POST["$field"]) || empty($_POST["$field"])) {
        $logger->log('Failed article upload attempt due to missing ' . "$field" . ' field');
        $return_data['error'] = "Submission failed: <strong>$field</strong> cannot be empty";
        exit(json_encode($return_data));
    }
}

// Get input
$user_id = $_SESSION['user_id'];
$article_id = $_POST['article_id'];
$text = trim($_POST['text']);
$posted_date = date("Y-m-d h:i:s", time());

// Validate as integers just in case
$user_id = filter_var($user_id, FILTER_VALIDATE_INT);
$article_id = filter_var($article_id, FILTER_VALIDATE_INT);

// Preparing and executing query
$query = "INSERT INTO `comment` (
                    comment_id,
                    `text`,
                    posted_date,
                    fk_user_id,
                    fk_article_id
              ) VALUES (NULL, ?, ?, ?, ?)";

if ($stmt = $mysqli->prepare($query)) {
    $stmt->bind_param("ssii", $text, $posted_date, $user_id, $article_id);

    if ($stmt->execute()) {
        // If insert successful
        $logger->log("Comment posted by user_id $user_id");

        $mysqli->close();
        $stmt->close();

        $return_data['success'] = '<strong>Success</strong>! Comment posted';
        exit(json_encode($return_data));
    } else {
        // If insert fails
        $logger->log("Failed comment posting attempt by user_id $user_id: ($mysqli->errno) $mysqli->error");

        $mysqli->close();
        $stmt->close();

        $return_data['error'] = '<strong>Failure Code 010</strong>! Please contact support';
        exit(json_encode($return_data));
    }
} else {
    // If prepare() failed
    $logger->log("Failed comment posting attempt by user_id $user_id: ($mysqli->errno) $mysqli->error");

    $return_data['error'] = '<strong>Failure Code 020</strong>! Please contact support';
    exit(json_encode($return_data));
}
