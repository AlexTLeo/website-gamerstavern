<?php
$return_comments = array();
// Pre-checks
require('control_header.php');
global $mysqli;

// Object to log operations
require('../Logger.php');
$logger = new Logger('comments.log', '/logs/');

// Object to purify article HTML in output
require_once('../htmlpurifier/library/HTMLPurifier.auto.php');
$config = HTMLPurifier_Config::createDefault();
$purifier = new HTMLPurifier($config);

// Object to filter out bad words (italian)
require_once('../Filterer.php');
$filterer = new Filterer('/whitelists/blacklist_ita.txt');

checkConnection($mysqli, $logger);

// Required data
$article_id = $_GET['article_id'];
$article_id = filter_var($article_id, FILTER_VALIDATE_INT);

// Preparing and executing query
$query = "SELECT `comment`.comment_id, 
                 `comment`.`text`, 
                 `comment`.posted_date, 
                 `comment`.fk_user_id,
                 `comment`.fk_article_id,
                 `user`.name,
                 `user`.surname,
                 `user`.profile_image_url
          FROM `comment`
          INNER JOIN `user` ON `comment`.fk_user_id=`user`.user_id 
          WHERE `comment`.fk_article_id=?
          ORDER BY posted_date DESC
          LIMIT 100";

if ($stmt = $mysqli->prepare($query)) {
    $stmt->bind_param("i", $article_id);
} else {
    exit("Fatal error: ($mysqli->errno) $mysqli->error");
}

$stmt->execute();
$stmt->bind_result($comment_id, $text, $posted_date, $fk_user_id, $fk_article_id,
        $name, $surname, $profile_image_url);
$stmt->store_result();

while ($stmt->fetch()) {
    // Making sure output tags are okay and filtering bad words
    $text = $purifier->purify($text);
    $text = $filterer->filterBlacklist($text);
    $text = htmlspecialchars($text);
    $name = $purifier->purify($name);
    $name = $filterer->filterBlacklist($name);
    $name = htmlspecialchars($name);
    $surname = $purifier->purify($surname);
    $surname = $filterer->filterBlacklist($surname);
    $surname = htmlspecialchars($surname);
    $comment_id = filter_var($comment_id, FILTER_VALIDATE_INT);
    $fk_user_id = filter_var($fk_user_id, FILTER_VALIDATE_INT);

    // Array of arrays (articles)
    array_push($return_comments, array(
        'comment_id' => $comment_id,
        'text' => $text,
        'posted_date' => $posted_date,
        'fk_user_id' => $fk_user_id,
        'name' => $name,
        'surname' => $surname,
        'profile_image_url' => $profile_image_url
    ));
}

$stmt->free_result();
$stmt->close();
$mysqli->close();

// Output is ready
exit(json_encode($return_comments));