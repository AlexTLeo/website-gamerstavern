<?php
// Pre-checks
require('control_header.php');
global $mysqli;

// Object to log operations
require('../Logger.php');
$logger = new Logger('logins.log', '/logs/');

checkConnection($mysqli, $logger);

// Checking if all required fields have been sent
$required_fields = array('email', 'pass');

foreach ($required_fields as $field) {
    if (!isset($_POST["$field"]) || empty($_POST["$field"])) {
        $logger->log('Failed login attempt due to missing ' . "$field" . ' field');
        $return_data['error'] = "Login failed: <strong>$field</strong> cannot be empty";
        exit(json_encode($return_data));
    }
}

// Sanitize and validate input
$email_original = $_POST['email'];
$email = $_POST['email'];
$password = $_POST['pass'];

$email = filter_var($email, FILTER_SANITIZE_EMAIL);
$email = filter_var($email, FILTER_VALIDATE_EMAIL);

// If email validator changed the email in any way (because it was invalid)
if ($email != $email_original) {
    $logger->log('Failed login attempt: email contains invalid characters: ' . $_POST['email']);
    $return_data['error'] = "Login failed: <strong>email</strong> contains invalid characters";
    exit(json_encode($return_data));
}

// Preparing and executing query
$query = "SELECT user_id, password, is_writer, `name`, surname
          FROM `user`
          WHERE email = ? LIMIT 1";

if ($stmt = $mysqli->prepare($query)) {
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $stmt->bind_result($user_id, $hashed_password, $is_writer, $name, $surname);
    $stmt->store_result();

    // If invalid email
    if ($stmt->num_rows == 0) {
        $logger->log('Failed login attempt (email does not exist) with email "' . $_POST['email']);

        $mysqli->close();
        $stmt->free_result();
        $stmt->close();

        $return_data['error'] = "Login failed: <strong>email</strong> does not exist";
        exit(json_encode($return_data));
    }

    // Checking password
    if ($stmt->fetch() && password_verify($password, $hashed_password)) {
        // Successful login
        $name = htmlspecialchars($name);
        $surname = htmlspecialchars($surname);

        $_SESSION['logged_in'] = true;
        $_SESSION['user_id'] = $user_id;
        $_SESSION['name'] = $name;
        $_SESSION['surname'] = $surname;
        $_SESSION['is_writer'] = $is_writer == true ? true : null;

        $logger->log('Successful login attempt with email "' . $_POST['email'] . '"');

        $mysqli->close();
        $stmt->free_result();
        $stmt->close();

        $return_data['success'] = '<strong>Login</strong> successful';
        exit(json_encode($return_data));
    } else {
        // If invalid password
        $logger->log('Failed login attempt (invalid password) with email ' . $_POST['email']);

        $mysqli->close();
        $stmt->free_result();
        $stmt->close();

        $return_data['error'] = 'Login failed: <strong>password</strong> invalid';
        exit(json_encode($return_data));
    }
} else {
    // If prepare() failed
    $logger->log('Query error with email ' . $_POST['email'] .
        ': (' . $mysqli->errno . ') ' . $mysqli->error);

    $return_data['error'] = 'Login failed: please try again later';
    exit(json_encode($return_data));
}