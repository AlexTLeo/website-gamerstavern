<?php

// if session not started, session_start
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

const validPages = array('homepage', 'blog', 'about', 'profile');
define('urlPrefix', '../../include/');

if (!isset($_GET['page'])) {
    $_GET['page'] = 'homepage';
}

$pageName = $_GET['page'];
$pageName = strtolower($pageName);

// Name conversions
switch ($pageName) {
    case 'home':
        $pageName = 'homepage';
        break;
    case 'chisiamo':
        $pageName = 'about';
        break;
    case 'account':
        $pageName = 'profile';
        break;
    default:
        break;
}

if (in_array($pageName, validPages, true)) {
    include(urlPrefix . "$pageName" . '.php');
} else {
    include(urlPrefix . '404.php');
}