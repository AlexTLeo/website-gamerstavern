<?php

/**
 * Class Logger: used to log errors or other information to specified files
 */
class Logger {
    private $fileName;
    private $path;

    function __construct($fileName, $path) {
        $this->fileName = $fileName;
        $this->path = $path;
    }

    function log($message) {
        $fileUrl = __DIR__ . $this->path . $this->fileName;
        $date_now = date("Y-m-d H:i:s");
        $logFile = fopen($fileUrl, 'a') or exit('Logger: unable to open log file');
        fwrite($logFile, $date_now . ': ' . $message . PHP_EOL);
        fclose($logFile);
    }
}