$(document).ready(function () {
    /** ====== START Miscellaneous Setups ====== */
    // How long before comment section gets refreshed?
    const COMMENT_REFRESH_TIMER_MILLISECONDS = 5000;

    // Get all elements to animate
    let elementsToShow = document.querySelectorAll('.animated-on-scroll');

    /** Make sure back and forward buttons reload the browser */
    $(window).on("popstate", function (e) {
        if (e.originalEvent.state !== null) {
            location.reload()
        }
    });

    /**
     * Bootstrap Alerts
     */
    // Close alert button
    $('.btn-close-alert').click(function () {
        $(this).parents('div').hide();
        $('.alert').hide();
    });
    /** ====== END Miscellaneous Setups ====== */

    /** ====== START Dynamic Navbar ====== */
    // If user logged in, show log out button
    if ($('#loggedin').val() === "true") {
        $('#logOutButtonParent').css('display', 'inline-block');
    }

    // Navbar links
    $('.nav-link').on('click', function () {
        let $param = this.textContent;
        let isLoadingAccount = false;

        // Special case: log out
        if (this.id == 'logOutButton') {
            $('#logOutButtonParent').css('display', 'none');
            $('.alert-success').show();
            $('#alertSuccessContent').html("<strong>Logout</strong> avvenuto. Grazie per essere passato dalla taverna!");
            $('#loggedin').val('');

            // Quick fetch to log out and then reload homepage
            fetch('protected/controllers/logout.php');

            $param = 'home';
        } else if ((this.id == 'accountButton' && $('#loggedin').val() === 'true')) {
            isLoadingAccount = true;
        }

        $param = $param.toLowerCase();
        $param = $param.replace(/\s/g, '');
        let $url = 'protected/controllers/page_selector.php?page=' + $param;

        fetch($url).then(function (response) {
            return response.text();
        }).then(function (page) {
            $('#pageToLoad').html(page);
            $('#pageToLoad').ready(function () {
                // Special case: show profile
                if (isLoadingAccount) {
                    enableProfileUpdate();
                }

                // Get all elements to animate
                elementsToShow = document.querySelectorAll('.animated-on-scroll');
                // Reset so animations can run again
                setVisibleOrNot();
                // Change URL so refresh keeps on same page
                window.history.pushState("", "", "/~S4633433/gamerstavern/" + $param);
            });
        });
    });
    /** ====== END Dynamic Navbar ====== */

    /** ====== START Profile Update ====== */
    /** Deals with profile update */
    function enableProfileUpdate() {
        const PATH_PROFILE_PICS = '/~S4633433/img/users/profile_pictures/';
        $rollbackButton = $('#profilepicCancel');
        $deleteImgButton = $('#defaultImageSubmit');

        fetch('protected/controllers/show_profile.php').then(function (response) {
            return response.json();
        }).then(function (responseJSON) {
            const FILENAME_CURRENT_IMG = responseJSON.profilepic_url;
            const FILENAME_DEFAULT_IMG = 'profile-default.png';
            $currentFirstname = responseJSON.firstname;
            $currentLastname = responseJSON.lastname;
            $currentEmail = responseJSON.email;
            $currentProfilepic = FILENAME_CURRENT_IMG;
            $('#firstname').val($currentFirstname);
            $('#lastname').val($currentLastname);
            $('#email').val($currentEmail);
            $('#profilepicPreviewUpdate').attr('src', PATH_PROFILE_PICS + $currentProfilepic);


            // Cannot delete profile image if it is already default!
            if (FILENAME_CURRENT_IMG === FILENAME_DEFAULT_IMG) {
                $deleteImgButton.prop('disabled', true);
            }

            // When I click on resetButton then reset values to original
            $('#resetButton').on('click', function () {
                $('#firstname').val($currentFirstname);
                $('#lastname').val($currentLastname);
                $('#email').val($currentEmail);
                $('#profilepicPreviewUpdate').attr('src', PATH_PROFILE_PICS + $currentProfilepic);
                $('#updateSubmit').hide();
                $('#resetButton').hide();
            })

            // Enable button to "rollback" to old profile picture after trying to change it
            $rollbackButton.on('click', function () {
                $('#profilepic').val(null);
                $('#profilepicPreviewUpdate').attr('src', PATH_PROFILE_PICS + $currentProfilepic);
                $rollbackButton.prop('disabled', true); // disable delete button

                // Allow users to rollback to default image
                if ($currentProfilepic !== 'profile-default.png') {
                    $deleteImgButton.prop('disabled', false); // Enable rollback button
                }
            });

            // Enable button delete profile image and enable cancel all changes button
            $deleteImgButton.on('click', function () {
                $('#profilepic').val(null);
                $('#profilepicPreviewUpdate').attr('src', PATH_PROFILE_PICS + FILENAME_DEFAULT_IMG);
                $rollbackButton.prop('disabled', true);
                $('#updateSubmit').show();
                $('#resetButton').show();
                $deleteImgButton.prop('disabled', true);
            });

            // When user changes any field
            $('#firstname, #lastname, #email, #profilepic, #profilepicCancel, #defaultImageSubmit').on('input change click', function () {
                // If all values are identical to the starting values
                if ($('#profilepic')[0].files[0] == null && $('#firstname').val() == $currentFirstname &&
                    $('#lastname').val() == $currentLastname && $('#email').val() == $currentEmail) {

                    // If profile image preview is the default image but original profile image isn't
                    // then make visible updateSubmit and resetSubmit
                    if ($('#profilepicPreviewUpdate').attr('src') === (PATH_PROFILE_PICS + FILENAME_DEFAULT_IMG) &&
                        ($currentProfilepic !== FILENAME_DEFAULT_IMG)) {
                        $('#updateSubmit').show();
                        $('#resetButton').show();
                    } else {
                        $('#updateSubmit').hide();
                        $('#resetButton').hide();
                    }
                } else {
                    $('#updateSubmit').show();
                    $('#resetButton').show();
                }
            });

            // When user tries to upload new picture...
            $('#profilepic').on('input', function () {
                if ($('#profilepic')[0].files && $('#profilepic')[0].files[0]) {
                    // User can confirm updates, roll back image or delete profile picture
                    $('#updateSubmit').show();
                    $deleteImgButton.prop('disabled', false);
                    $rollbackButton.prop('disabled', false);

                    // Change image preview
                    let reader = new FileReader();
                    reader.onload = function (e) {

                        $('#profilepicPreviewUpdate').attr('src', e.target.result);
                    }

                    reader.readAsDataURL(this.files[0]);
                } else {
                    $('#profilepicPreviewUpdate').attr('src', PATH_PROFILE_PICS + $currentProfilepic);
                }
            });

            // If a user click on updateSubmit, call update_profile.php
            $('#updateSubmit').on('click', function () {
                let $url = 'protected/controllers/update_profile.php';

                // Using FormData to encode images as well as text
                let formData = new FormData();
                $firstname = $('#formUpdateProfile').find('#firstname').val();
                $lastname = $('#formUpdateProfile').find('#lastname').val();
                $email = $('#formUpdateProfile').find('#email').val();
                $profilepic = null;

                // If no changes were made to the profile picture
                if ($('#profilepic')[0].files[0] == null &&
                    $('#profilepicPreviewUpdate').attr('src') !== PATH_PROFILE_PICS + FILENAME_DEFAULT_IMG) {
                    $profilepic = FILENAME_CURRENT_IMG;
                } else if ($('#profilepicPreviewUpdate').attr('src') == PATH_PROFILE_PICS + FILENAME_DEFAULT_IMG) {
                    // If user wants to delete his profile image
                    $profilepic = 'profile-default.png';
                } else {
                    // Else (if a user uploads something) set his profile image with his upload
                    $profilepic = $('#profilepic')[0].files[0];
                }

                // Build formData to send in post
                formData.append('firstname', $firstname);
                formData.append('lastname', $lastname);
                formData.append('email', $email);
                formData.append('profilepic', $profilepic);

                // Building Response
                const pageRequest = new Request($url, {
                    method: 'post',
                    body: formData
                });

                // Actual request (fetch)
                fetch(pageRequest).then(function (response) {
                    return response.json();
                }).then(function (responseJSON) {
                    // Outputting error or success messages via modal
                    if (responseJSON.error) {
                        $('.alert-danger').show();
                        $('#alertErrorContent').html(responseJSON.error);
                    } else if (responseJSON.success) {
                        $currentFirstname = $.trim($firstname);
                        $currentLastname = $.trim($lastname);
                        $currentEmail = $.trim($email);
                        $('#firstname').val($currentFirstname);
                        $('#lastname').val($currentLastname);
                        $('#email').val($currentEmail);
                        $currentProfilepic = responseJSON.profilepic;
                        $('#profilepic').val(null);
                        $rollbackButton.prop('disabled', true);
                        $('#updateSubmit').hide();
                        $('#resetButton').hide();

                        $('.alert-success').show();
                        $('#alertSuccessContent').html(responseJSON.success);
                        $('#logOutButtonParent').css('display', 'inline-block');
                    }
                });

                // Refreshing animations script
                $('#profilePageContent').ready(function () {
                    // Get all elements to animate
                    elementsToShow = document.querySelectorAll('.animated-on-scroll');
                    // Reset so animations can run again
                    setVisibleOrNot();
                })
            });
        })
    }

    $(window).on('load', function () {
        if ($('#formUpdateProfile').length) {
            enableProfileUpdate();
        }
    })
    /** ====== END Profile Update ====== */

    /** Registration Button */
    // Why not directly listen for #linkToRegisterPage? Because when pages are loaded that
    // button does not exist yet. jQuery needs to attach the listener to something that
    // already exists, so we attach it to #pageToLoad and make sure it only fires if the
    // child is #linkToRegisterPage
    $('#pageToLoad').on('click', '#linkToRegisterPage', function () {
        let $url = 'include/components/registration_form.php';

        fetch($url).then(function (response) {
            return response.text();
        }).then(function (page) {
            $('#profilePageContent').html(page);
            $('#profilePageContent').ready(function () {
                // Get all elements to animate
                elementsToShow = document.querySelectorAll('.animated-on-scroll');
                // Reset so animations can run again
                setVisibleOrNot();
            });
        });

    })

    /** ====== START Login/Registration/Update Submit Listeners ====== */
    /** Login */
    $('#pageToLoad').on('click', '#loginSubmit', function () {
        let $url = 'protected/controllers/login.php';

        // Using FormData to encode images as well as text
        let formData = new FormData();
        $email = $('#formLogin').find('#email').val();
        $pass = $('#formLogin').find('#pass').val();

        formData.append('email', $email);
        formData.append('pass', $pass);

        // Building Request
        const pageRequest = new Request($url, {
            method: 'post',
            body: formData
        });

        // Actual request (fetch)
        fetch(pageRequest).then(function (response) {
            return response.json();
        }).then(function (responseJSON) {
            // Outputting error or success messages via alert
            if (responseJSON.error) {
                $('.alert-danger').show();
                $('#alertErrorContent').html(responseJSON.error);
            } else if (responseJSON.success) {
                $('.alert-success').show();
                $('#alertSuccessContent').html(responseJSON.success);
                $('#logOutButtonParent').css('display', 'inline-block');
                $('#loggedin').val("true");

                // On login send user to profile page
                fetch('include/components/profile_form.php', {method: 'post'}).then(response => response.text()).then(
                    text => $('#profilePageContent').html(text)
                ).then(function () {
                    enableProfileUpdate();
                })
            }

            // Refreshing animations script
            $('#profilePageContent').ready(function () {
                // Get all elements to animate
                elementsToShow = document.querySelectorAll('.animated-on-scroll');
                // Reset so animations can run again
                setVisibleOrNot();
            });
        })
    });

    /** Registration */
    $('#pageToLoad').on('click', '#registrationSubmit', function () {
        let $url = 'protected/controllers/registration.php';

        // Using FormData to encode images as well as text
        let formData = new FormData();
        $firstname = $('#formRegister').find('#firstname').val();
        $lastname = $('#formRegister').find('#lastname').val();
        $email = $('#formRegister').find('#email').val();
        $pass = $('#formRegister').find('#pass').val();
        $passconfirm = $('#formRegister').find('#confirm').val();
        $profilepic = $('#formRegister').find('#profilepic')[0].files[0];

        formData.append('firstname', $firstname);
        formData.append('lastname', $lastname);
        formData.append('email', $email);
        formData.append('pass', $pass);
        formData.append('confirm', $passconfirm);
        formData.append('profilepic', $profilepic);

        // Building Response
        const pageRequest = new Request($url, {
            method: 'post',
            body: formData
        });

        // Actual request (fetch)
        fetch(pageRequest).then(function (response) {
            return response.json();
        }).then(function (responseJSON) {
            // Outputting error or success messages via modal
            if (responseJSON.error) {
                $('.alert-danger').show();
                $('#alertErrorContent').html(responseJSON.error);
            } else if (responseJSON.success) {
                $('.alert-success').show();
                $('#alertSuccessContent').html(responseJSON.success);

                // On registration send user to login page
                fetch('include/components/login_form.php').then(response => response.text()).then(
                    text => $('#profilePageContent').html(text)
                )
            }

            // Refreshing animations script
            $('#profilePageContent').ready(function () {
                // Get all elements to animate
                elementsToShow = document.querySelectorAll('.animated-on-scroll');
                // Reset so animations can run again
                setVisibleOrNot();
            });
        })
    });

    /** Registration Image Preview */
    /** Check if file is uploaded and display preview/enable upload deletion */
    $('#pageToLoad').on('DOMSubtreeModified', function () {
        // Display preview and enable/disable deletion
        $('#pageToLoad').find('#profilepic').on('change', function () {
            if ($('#profilepic')[0].files && $('#profilepic')[0].files[0]) {
                $('#profilepicCancel').prop('disabled', false);
                let reader = new FileReader();
                reader.onload = function (e) {

                    $('#profilepicPreview').attr('src', e.target.result);
                }

                reader.readAsDataURL(this.files[0]);
            } else {
                $('#profilepicCancel').prop('disabled', true);
            }
        });

        // Delete profile image preview
        $('#pageToLoad').find('#profilepicCancel').on('click', function () {
            $('#profilepic').val(null);
            $('#profilepicPreview').attr('src', '/~S4633433/img/users/profile_pictures/profile-default.png');
            $('#profilepicCancel').prop('disabled', true);
        });
    });
    /** ====== EMD Login/Registration/Update Submit Listeners ====== */

    /** ====== START Blog Specific ====== */

    /**  START Blog Listeners */
    // On nav-link click
    $('#blogNavLink').on('click', function () {
        activateBlogListeners();
    })

    // On page refresh
    $(window).on('load', function () {
        activateBlogListeners();
    })

    function activateBlogListeners() {
        let pageOffset = 0;

        /** Pagination */
        let checkExistPageNav = setInterval(function () {
            if ($('#articlePrevious').length && $('#articleNext').length) {
                clearInterval(checkExistPageNav);

                $('#articlePrevious').on('click', function () {
                    if (pageOffset >= 5) {
                        pageOffset -= 5;
                    }

                    $input = $('#articleSearch').val();
                    loadArticles($input, false, pageOffset);
                })

                $('#articleNext').on('click', function () {
                    pageOffset += 5;
                    $input = $('#articleSearch').val();
                    loadArticles($input, false, pageOffset);
                })
            }
        }, 100);

        /** Article Search Bar load */
        $('#pageToLoad').on('click', '#articleSearchButton', function () {
            $input = $('#articleSearch').val();
            loadArticles($input, false, 0);
        })

        /** Article Category Search Buttons load */
        let checkExistCategories = setInterval(function () {
            if ($('.category-button').length) {
                clearInterval(checkExistCategories);
                $('.category-button').on('click', function () {
                    $category = this.querySelector("footer").textContent;
                    loadArticles($category, true, 0);
                })
            }
        }, 100);

        let checkExistContainer = setInterval(function () {
            if ($('#articlePreviewsContainer').length) {
                /** Article Load */
                loadArticles("", false, 0);
                /** "Write Article" button */
                $('#buttonWriteArticle').on('click', function () {
                    showArticleWriter();
                });

                clearInterval(checkExistContainer);
            }
        }, 100);
    }
    /** END Blog Listeners */

    /**
     * Activate Article Writing Page
     */
    function showArticleWriter() {
        fetch('include/components/writer_panel.php').then(
            response => response.text()
        ).then(
            function (responseText) {
                $('#blogContentContainer').html(responseText);

                /** Editor */
                let checkExistEditor = setInterval(function () {
                    if ($('#articleEditor').length) {
                        tinymce.remove();
                        tinymce.init({
                            selector: '#articleEditor',
                            skin: 'bootstrap',
                            plugins: 'lists, link, image, media',
                            toolbar: 'h1 h2 bold italic strikethrough blockquote bullist numlist backcolor | link image media | removeformat help',
                            menubar: true,
                            content_style: "" +
                                "body { background-color: #eeeeee !important; }"
                        });
                        clearInterval(checkExistEditor);
                    }
                }, 100);

                /** New Article Submit (button) */
                (function checkExistSubmitArticle() {
                    if ($('#submitNewArticle').length) {
                        $('#submitNewArticle').on('click', function () {
                            let $url = 'protected/controllers/insert_article.php';

                            // Using FormData to encode images as well as text
                            let formData = new FormData();
                            $title = $('#title').val();
                            $author = $('#author').val();
                            $banner_image = $('#bannerImage')[0].files[0];
                            $category = $('#categorySelect').val();
                            $body = tinymce.activeEditor.getContent();

                            formData.append('title', $title);
                            formData.append('author', $author);
                            formData.append('category', $category);
                            formData.append('body', $body);
                            formData.append('banner_image', $banner_image);

                            // Building Response
                            const pageRequest = new Request($url, {
                                method: 'post',
                                body: formData
                            });

                            // Actual request (fetch)
                            fetch(pageRequest).then(function (response) {
                                return response.json();
                            }).then(function (responseJSON) {
                                // Outputting error or success messages via alert
                                if (responseJSON.error) {
                                    $('.alert-danger').show();
                                    $('#alertErrorContent').html(responseJSON.error);
                                } else if (responseJSON.success) {
                                    $('.alert-success').show();
                                    $('#alertSuccessContent').html(responseJSON.success);

                                    // After article is sent, reload blog content
                                    fetch('protected/controllers/page_selector.php?page=blog').then(response => response.text()).then(
                                        function (responseText) {
                                            $('#pageToLoad').html(responseText);
                                            $('#pageToLoad').ready(function () {
                                                activateBlogListeners();
                                            })
                                        }
                                    )
                                }

                                // Refreshing animations script
                                $('#profilePageContent').ready(function () {
                                    // Get all elements to animate
                                    elementsToShow = document.querySelectorAll('.animated-on-scroll');
                                    // Reset so animations can run again
                                    setVisibleOrNot();
                                });
                            })
                        })
                    } else {
                        setTimeout(checkExistSubmitArticle, 100);
                    }
                }) ();

            })
    }

    /**
     * Deletes an article
     * @param article_id - id of article to delete
     */
    function deleteArticle(article_id) {
        $url = 'protected/controllers/delete_article.php';
        let formData = new FormData();
        formData.append('article_id', article_id);

        // Building Response
        const deleteRequest = new Request($url, {
            method: 'post',
            body: formData
        });

        fetch(deleteRequest).then(response => response.json()).then(
            function (responseJSON) {
                // Outputting error or success messages via alert
                if (responseJSON.error) {
                    $('.alert-danger').show();
                    $('#alertErrorContent').html(responseJSON.error);
                } else if (responseJSON.success) {
                    $('.alert-success').show();
                    $('#alertSuccessContent').html(responseJSON.success);

                    // After article is deleted, reload blog content
                    fetch('protected/controllers/page_selector.php?page=blog').then(response => response.text()).then(
                        function (responseText) {
                            $('#pageToLoad').html(responseText);
                            $('#pageToLoad').ready(function () {
                                activateBlogListeners();
                            })
                        }
                    )
                }

                // Refreshing animations script
                $('#profilePageContent').ready(function () {
                    // Get all elements to animate
                    elementsToShow = document.querySelectorAll('.animated-on-scroll');
                    // Reset so animations can run again
                    setVisibleOrNot();
                });
            }
        )
    }

    /**
     * Sends a request to load all articles
     * @param searchInput - specify a search string to match articles loaded
     * @param flag_categorySearch - boolean, true means search only for categories that match searchInput
     * @param offset - how many rows to offset from select
     */
    function loadArticles(searchInput, flag_categorySearch, offset) {
        commentLoaderTimeoutLoop.forEach(element => clearTimeout(element));
        let suffixGET = '?search=' + searchInput + '&catonly=' + flag_categorySearch + '&offset=' + offset.toString();
        fetch('protected/controllers/article_loader.php' +
            suffixGET).then(response => response.json()).then(
            function (responseJSON) {
                // Load as many article_preview.php components into page as there are results from query
                // (there is a for loop in article_preview.php)
                let numArticles = Object.keys(responseJSON).length;
                let formDataArticles = new FormData();
                formDataArticles.append('articles_count', numArticles.toString());
                formDataArticles.append('articles', JSON.stringify(responseJSON));

                fetch('include/components/article_preview.php', {
                    method: 'post',
                    body: formDataArticles
                }).then(response => response.text()).then(
                    function (responseText) {
                        $('#articlePreviewsContainer').html(responseText);

                        $('#articlePreviewsContainer').ready(function () {
                            /** Activating Article Delete buttons */
                            let checkExistDeleteButtons = setInterval(function () {
                                if ($('.article-delete-button').length) {
                                    $('.article-delete-button').on('click', function () {
                                        $id = this.querySelector("input").value;
                                        deleteArticle($id);
                                    })

                                    clearInterval(checkExistDeleteButtons);
                                }
                            }, 100)

                            /** Make preview clickable */
                            let checkExistArticleLink = setInterval(function () {
                                if ($('.article-selection').length) {
                                    // Load article page
                                    $('.article-selection').on('click', function() {
                                        let article_id = this.querySelector('.article-id').value.toString();
                                        loadArticlePage(article_id);
                                    });

                                    clearInterval(checkExistArticleLink);
                                }
                            }, 100)

                            // Refreshing animations script
                            $('#profilePageContent').ready(function () {
                                // Get all elements to animate
                                elementsToShow = document.querySelectorAll('.animated-on-scroll');
                                // Reset so animations can run again
                                setVisibleOrNot();
                            });
                        })
                    }
                )
            }
        )
    }

    /**
     * Load a single full article onto page and display/enable live comments
     * @param article_id - id of article to load
     */
    let commentLoaderTimeoutLoop = [];
    function loadArticlePage (article_id) {
        commentLoaderTimeoutLoop.forEach(element => clearTimeout(element));

        article_id = article_id.toString();
        let url = '/~S4633433/protected/controllers/article_loader.php?article_id=' + article_id;

        fetch(url).then(response => response.json()).then(
            function (responseJSON) {
                let articleFormData = new FormData();
                articleFormData.append('articles', JSON.stringify(responseJSON));

                // Building Response
                const articleRequest = new Request('/~S4633433/include/components/article.php', {
                    method: 'post',
                    body: articleFormData
                });

                fetch(articleRequest).then(response => response.text()).then(
                    function (responseText) {
                        $('#articlePreviewsContainer').html(responseText);

                        /** Allow users to post comments on articles */
                        let checkExistCommentBox = setInterval(function () {
                            if ($('#commentInput').length) {
                                $('#submitComment').on('click', function () {
                                    let url = 'protected/controllers/insert_comment.php';
                                    let commentFormData = new FormData();

                                    $text = $('#commentInput').val();

                                    // Empty comment box on submit!
                                    $('#commentInput').val("");

                                    commentFormData.append('article_id', article_id);
                                    commentFormData.append('text', $text);

                                    const postCommentRequest = new Request(url, {
                                        method: 'post',
                                        body: commentFormData
                                    })

                                    fetch(postCommentRequest).then(response => response.json()).then(
                                        function (responseJSON) {
                                            // Outputting error or success messages via alert
                                            if (responseJSON.error) {
                                                $('.alert-danger').show();
                                                $('#alertErrorContent').html(responseJSON.error);
                                            } else if (responseJSON.success) {
                                                $('.alert-success').show();
                                                $('#alertSuccessContent').html(responseJSON.success);

                                                // Immediately refresh comment section!
                                                loadComments(article_id);
                                            }
                                        }
                                    )
                                })

                                clearInterval(checkExistCommentBox);
                            }
                        }, 100);

                        /** Load and keep comment section updated regularly by polling database */
                        (function updateCommentSection () {
                            loadComments(article_id);
                            // Keep loading comments every 5 seconds
                            commentLoaderTimeoutLoop.push(setTimeout(updateCommentSection, COMMENT_REFRESH_TIMER_MILLISECONDS));
                        })();
                    }
                )
            }
        )
    }

    /**
     * Load all relevant comments under the specified article
     * @param article_id
     */
    function loadComments(article_id) {
        fetch('protected/controllers/comment_loader.php?article_id=' + article_id).then(
            response => response.json().then(
                function (responseJSON) {
                    let commentFormData = new FormData();
                    let numComments = Object.keys(responseJSON).length;
                    commentFormData.append('comments', JSON.stringify(responseJSON));
                    commentFormData.append('comments_count', numComments.toString());

                    // Building Response
                    const commentsRequest = new Request('/~S4633433/include/components/comment_section.php', {
                        method: 'post',
                        body: commentFormData
                    });

                    fetch(commentsRequest).then(response => response.text()).then(
                        function (responseText) {
                            if ($('#commentSection').length) {
                                $('#commentSection').html(responseText);

                                /** Enable comment deletion */
                                let checkExistCommentDelete = setInterval(function () {
                                    if ($('.comment-delete-button').length) {
                                        $('.comment-delete-button').on('click', function () {
                                            $comment_id = this.querySelector(".comment-id").value;
                                            $comment_poster_id = this.querySelector(".comment-poster-id").value;

                                            let deleteData = new FormData();
                                            deleteData.append('comment_id', $comment_id);
                                            deleteData.append('article_id', article_id);
                                            deleteData.append('comment_poster_id', $comment_poster_id);

                                            let commentDeleteRequest = new Request('protected/controllers/delete_comment.php', {
                                                method: 'post',
                                                body: deleteData
                                            })

                                            fetch(commentDeleteRequest).then(response => response.json()).then(
                                                function (responseJSON) {
                                                    // Outputting error or success messages via alert
                                                    if (responseJSON.error) {
                                                        $('.alert-danger').show();
                                                        $('#alertErrorContent').html(responseJSON.error);
                                                    } else if (responseJSON.success) {
                                                        $('.alert-success').show();
                                                        $('#alertSuccessContent').html(responseJSON.success);

                                                        // Immediately refresh comment section!
                                                        loadComments(article_id);
                                                    }
                                                }
                                            )
                                        })

                                        clearInterval(checkExistCommentDelete);
                                    }
                                }, 100);
                            }
                        }
                    )
                }
            )
        )
    }

    /** ====== END Blog Specific ====== */

    /** ====== Scroll Parallax ====== */
    $('body').scroll(function () {
        let scroll = $('body').scrollTop();
        let temp = 100 - (scroll - 1200) / 128;
        let bonus = '50% ' + temp * -1 + '%';
        $(".parallax-on-scroll").css("background-position", bonus);
    });

    /** ====== START Animations ====== */
        // Callback every frame or 60 times a second for old browsers that
        // don't support requestAnimationFrame
    let onFrameRefresh = window.requestAnimationFrame ||
        function (callback) {
            window.setTimeout(callback, 1000 / 60)
        };

    // looping function from: http://stackoverflow.com/a/7557433/274826
    function setVisibleOrNot() {
        // Check if all elements are already visible
        let isAllVisible = true;

        elementsToShow.forEach(function (element) {
            // If element is in viewport AND it doesn't already contain class visible then add it
            if (!element.classList.contains('visible')) {
                isAllVisible = false;

                if (isElementInViewport(element)) {
                    element.classList.add('visible');
                }
            }
            // Adding this will animate even if you scroll back towards the element, rather than just once
            // else {
            //     element.classList.remove('visible');
            // }
        });

        // No point in continuing callback if all elements are visible
        if (!isAllVisible) {
            onFrameRefresh(setVisibleOrNot);
        }
    }

    // Finding if elements are in viewport
    function isElementInViewport(el) {
        // jQuery bug fix
        if (typeof jQuery === "function" && el instanceof jQuery) {
            el = el[0];
        }

        let rect = el.getBoundingClientRect();

        return (
            (rect.top <= 0
                && rect.bottom >= 0)
            ||
            (rect.bottom >= (window.innerHeight || document.documentElement.clientHeight) &&
                rect.top <= (window.innerHeight || document.documentElement.clientHeight))
            ||
            (rect.top >= 0 &&
                rect.bottom <= (window.innerHeight || document.documentElement.clientHeight))
        );
    }

    setVisibleOrNot();
    /** ====== END Animations ====== */
});