<?php
session_start();
?>

<!DOCTYPE html>
<html lang='en-gb'>
<head>
    <base href="/~S4633433/">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta charset='UTF-8'>
    <title>Gamer's Tavern</title>

    <!-- Favicon -->
    <link rel="icon" type="image/png" href="img/logo.png"/>

    <!-- Bootstrap -->
    <!--    <link rel='stylesheet' href='css/style.css'/>-->
    <!-- TODO: Remove temp stuff -->
    <link rel='stylesheet' href='css/tempcssalex.css'/>
    <link rel='stylesheet' href='css/tempcssdylan.css'/>
    <link rel='stylesheet' href='css/animatons.css'/>
    <link rel='stylesheet' href='css/bootstrap.css'/>
</head>

<body>
<!-- START Alerts -->
<div class="alert alert-danger alert-dismissible fade show" role="alert">
    <i class="fas fa-exclamation pe-3"></i>
    <span id='alertErrorContent' class='m-0 d-inline'>
        Qualcosa è andato male
    </span>
    <button type="button" class="btn-close btn-close-alert" aria-label="Close"></button>
</div>

<div class="alert alert-success alert-dismissible fade show" role="alert">
    <i class="fas fa-check pe-3"></i>
    <span id='alertSuccessContent' class='m-0 d-inline'>
        L'operazione è andata a buon fine
    </span>
    <button type="button" class="btn-close btn-close-alert" aria-label="Close"></button>
</div>
<!-- END Alerts -->
<div class='d-flex flex-column min-vh-100'>
    <a id='anchor-to-top'></a>

    <?php
    // Navbar
    include('include/components/navbar.php');
    ?>

    <!--Body-->
    <div class='container>'>
        <div class='row'>
            <div id='pageToLoad' class='d-flex flex-column min-vh-100'>
                <!-- Loaded via Fetch, default is homepage -->
                <?php
                if (!isset($_GET['page'])) {
                    $_GET['page'] = 'homepage';
                }

                switch ($_GET['page']) {
                    case 'home':
                    case 'homepage':
                        include('include/homepage.php');
                        break;
                    case 'blog':
                        include('include/blog.php');
                        break;
                    case 'account':
                        include('include/profile.php');
                        break;
                    case 'chisiamo':
                        include('include/about.php');
                        break;
                    default:
                        include('include/404.php');
                        break;
                }
                ?>
            </div>
        </div>
    </div>

    <?php
    // Footer
    include('include/components/footer.php');
    ?>
</div>

<!-- TinyMCE -->
<script src="https://cdn.tiny.cloud/1/ztu6sequfsx5wiz9902fo0c34er3iifmyewav1et7clragwh/tinymce/5/tinymce.min.js"
        referrerpolicy="origin"></script>
<!-- jQuery -->
<script src='js/jquery-3.5.1.js'></script>
<!-- Bootstrap -->
<script src='js/bootstrap.bundle.js'></script>
<!-- FontAwesome -->
<script src='https://kit.fontawesome.com/bdaf2a999c.js' crossorigin='anonymous'></script>
<!-- Scripts -->
<script src='js/script.js'></script>
<script src='js/dynamic-page-loader.js'></script>
</body>
</html>
