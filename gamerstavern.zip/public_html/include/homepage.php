<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
?>

<!-- Main Page -->
<div id='page-bg-container'>
    <img src='img/backgrounds/tavern-1.png' class='img-page-bg' alt='Picture of a medieval tavern'>
</div>

<div class="common-main homepage-main text-center container min-vh-100 p-3 mx-auto">
    <div class='row h-100 w-100 align-items-center'>
        <span>
            <img class='animated-on-scroll' src='img/logo.png' alt="Gamer's Tavern logo">
            <span class='animated-on-scroll mt-4'>La locanda degli avventurieri</span>
        </span>
    </div>
    <div class='common-main-arrow-container'>
        <a class='text-decoration-none text-white' href='#anchor-to-content'>
            <i class="common-main-arrow fas fa-angle-double-down"></i>
        </a>
    </div>
</div>

<!-- Content -->
<div class='parallax-on-scroll homepage-articles-container'>
    <!-- Banner -->
    <div class='container-fluid p-0 homepage-articles'>

        <!-- This div fixes weird bug with banner being detected in viewport on load -->
        <div class='row' style='height: 0.1px;'></div>

        <div class='animated-on-scroll slide-in-right-far row text-center'>
            <a id='anchor-to-content'></a>
            <header class='d-flex flex-column justify-content-center'>
                <h1>Benvenuti alla taverna</h1>
                <div>
                    <p>
                        Scopri le ultime news del mondo videoludico e facci sapere la tua opinione<br>
                        Visita il nostro <a href='javascript:void(0);' class='d-inline nav-link special-red text-decoration-none p-0 m-0'>blog</a> per ulteriori novità
                    </p>
                </div>
            </header>
        </div>
    </div>
</div>