<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Loading as many articles as is specified by jQuery
$article = json_decode($_POST['articles'], true)[0];

$article_id = $article['article_id'];
$banner_image_url = $article['banner_image_url'];
$title = $article['title'];
$author = $article['author'];
$body = $article['body'];
$posted_date = $article['posted_date'];
$category = $article['category'];
?>

<article class='article mx-0 px-0'>
    <!-- Banner Image -->
    <div class='container-fluid mx-0 px-0 mb-5'>
        <div class="row">
            <img src="img/blog/<?php echo $banner_image_url ?>"
                 alt="Immagine banner per l'articolo" class='article-banner'>
        </div>
    </div>

    <div class='container mx-auto px-0 animated-on-scroll slide-in-right'>

        <!-- Title -->
        <div class="row">
            <h1 class='article-title text-center' id='articleTitle'>
                <?php echo $title ?>
            </h1>
        </div>

        <!-- Author, posted date and category -->
        <div class="row">
            <p class='article-info text-center mt-1' id='articleAuthorDate'>
                <?php echo($author . ', ' . $posted_date . ', ' . $category) ?>
            </p>
        </div>

        <!-- Body -->
        <div class="row article-body">
            <p class='article-body text-center' id='articleBody'>
                <?php echo $body ?>
            </p>
        </div>

        <div class='text-white my-5 px-0 mx-0 d-flex align-items-center'>
            <div class='line-dark'></div>
            <span class='font-gamerstavern px-4 em-3 special-red'>Discussione</span>
            <div class='line-dark'></div>
        </div>
    </div>

    <!-- Comment Section -->
    <div class='container d-flex flex-column'>
        <div id='commentWriteBox' class='row animated-on-scroll fade-in-fwd d-flex align-self-center w-75'>
            <form action='javascript:void(0);' class='p-0 m-0 align-self-center d-flex flex-row' method='post'
                  enctype="multipart/form-data">
                <label for='commentInput' class='visually-hidden'>Scrivi Commento</label>
                <div class="input-group input-group-lg mb-3">
                <textarea name='commentInput' class='form-control' placeholder='Scrivi Commento...'
                          aria-label='scrivi commento' id='commentInput'></textarea>
                </div>
                <div class="input-group input-group-lg mb-3 w-25">
                    <input name='submit' type="submit" class="font-gamerstavern em-2 form-control btn btn-success"
                           value='Invia'
                           aria-label="Posta commento" id='submitComment'>
                </div>
            </form>
        </div>
        <div id='commentSection' class='row'>
            <span class="input-group-text bg-dark text-white border-warning">
                <?php include('comment_section.php') ?>
            </span>
        </div>
    </div>
    <div class='row divisor pb-5'></div>
</article>
