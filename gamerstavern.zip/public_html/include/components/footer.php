<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
?>

<footer class="footer-bg py-5 mt-auto mx-auto container-fluid">
    <div class="col-12 text-center mb-4">
        <a class="top-button hiddenLink" href='#anchor-to-top'>Torna Su</a>
    </div>
    <div class="row">
        <div class="col-12 mx-auto text-center pb-4">
            <img class="footer-logo" src="img/logo-white-black.png" alt="Gamer's Tavern Logo">
        </div>
    </div>
    <div class="row text-center mb-3">
        <span class="col-lg-3 mt-4">
                <a href="https://gamerstavern.bigcartel.com/">
                    <i class="fas fa-tshirt footer-icon"></i>
                </a>
        </span>
        <span class="col-lg-3 mt-4">
                <a href="https://www.twitch.tv/gamerstaverntv">
                    <i class="footer-icon fab fa-twitch"></i>
                </a>
        </span>
        <span class="col-lg-3 mx-auto mt-4">
                <a href="https://www.instagram.com/gamers_tavern/">
                    <i class="footer-icon fab fa-instagram"></i>
                </a>
        </span>
        <span class="col-lg-3 mx-auto mt-4">
                <a href="https://www.youtube.com/channel/UCTsMySEsef_BLDpofhpK77A?view_as=subscriber">
                    <i class="footer-icon fab fa-youtube"></i>
                </a>
        </span>
    </div>
    <div class="row">
        <div class="col-12 mt-4">
            <p class="copyright text-center">Copyright &copy; 2021 Gamer's Tavern | Designed By Thanaphon Leonardi & Dylan Lo Blundo</p>
        </div>
    </div>
</footer>
