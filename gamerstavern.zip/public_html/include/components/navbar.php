<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
?>

<nav class="navbar navbar-dark navbar-expand-lg bg-transparent position-absolute mt-5">
    <div class="container-fluid">
        <!-- jQuery checks for log out link -->
        <input type='hidden' name='loggedin' id='loggedin'
               value='<?php echo isset($_SESSION['logged_in']) ? "true" : "" ?>'>
        <ul class="navbar-nav vw-100 justify-content-center">
            <!-- When adding new items remember to change the nav-item-n class for animations -->
            <li class="animated-on-scroll nav-item nav-item-1 px-4">
                <a class="nav-link" href="javascript:void(0)">Home</a>
            </li>
            <li class="animated-on-scroll nav-item nav-item-2 px-4">
                <a class="nav-link" id='blogNavLink' href="javascript:void(0)">Blog</a>
            </li>
            <li class="animated-on-scroll nav-item nav-item-3 px-4">
                <a class="nav-link" href="javascript:void(0)">Chi Siamo</a>
            </li>
            <li class="animated-on-scroll nav-item nav-item-4 px-4">
                <a class="nav-link" id='accountButton' href="javascript:void(0)">Account</a>
            </li>
            <li class="animated-on-scroll nav-item nav-item-5 px-4" id='logOutButtonParent'>
                <a class="nav-link" id='logOutButton' href="javascript:void(0)">Log Out</a>
            </li>
        </ul>
    </div>
</nav>