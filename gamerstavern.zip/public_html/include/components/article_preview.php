<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Loading as many articles as is specified by jQuery
if (isset($_POST['articles'])) {
    $all_articles = json_decode($_POST['articles'], true);
    if (intval($_POST['articles_count']) > 0) {
        for ($i = 0; $i < intval($_POST['articles_count']); $i++) {
            $article = $all_articles[$i];
            $article_id = $article['article_id'];
            $banner_image_url = $article['banner_image_url'];
            $title = $article['title'];
            $author = $article['author'];
            $body = $article['body'];
            $posted_date = $article['posted_date'];
            $category = $article['category'];
            ?>
            <div class='row animated-on-scroll fade-in-fwd article-preview-container d-flex align-self-center mt-5'>
                <div class="card p-0 d-flex flex-column align-self-center">
                    <?php if (isset($_SESSION['is_writer']) && $_SESSION['is_writer'] == 1) { ?>
                        <span class='writer-tools-preview d-flex flex-column'>
                            <button class='btn btn-danger article-delete-button'>
                                <input type='hidden' class="article-id" value='<?php echo $article_id ?>'>
                                <i class="fas fa-trash"></i>
                            </button>
                            <button class='btn btn-success article-modify-button'>
                                <input type='hidden' class="article-id" value='<?php echo $article_id ?>'>
                                <i class="fas fa-edit"></i>
                            </button>
                        </span>
                    <?php } ?>
                    <a href='javascript:void(0)' class="article-selection">
                        <input type='hidden' class="article-id" value='<?php echo $article_id ?>'>
                        <div class='card-banner'>
                            <img src="img/blog/<?php echo $banner_image_url ?>" class="card-img-top"
                                 alt="Immagine banner per l'articolo">
                        </div>
                        <div class="card-body article-preview px-5">
                            <header class="card-title article-preview-title mb-0">
                                <?php echo $title ?>
                            </header>
                            <small class="text-muted article-preview-category mt-0 mb-5">
                                <?php echo $category ?>
                            </small>
                            <article class="card-text article-preview-body">
                                <?php echo $body ?>
                            </article>
                            <footer class="card-text article-preview-footer">
                                <small class="text-muted">
                                    <?php echo $author . ', ' . $posted_date ?>
                                </small>
                            </footer>
                        </div>
                    </a>
                </div>
            </div>
        <?php }
    } else { ?>
        <div class='p-5 animated-on-scroll fade-in-fwd row text-center search-null-container'>
            <header class='d-flex flex-column justify-content-center'>
                <h1 class='font-gamerstavern'>Nessun risultato <span class='face-sad'>:(</span></h1>
                <summary>
                    <p>
                        Ci dispiace che tu non abbia trovato ció che cercavi! Puoi sempre suggerirci un'idea per
                        un nuovo articolo durante <a target="_blank" href='https://www.twitch.tv/gamerstaverntv'>le
                            nostre
                            livestream!</a>
                    </p>
                </summary>
            </header>
        </div>
    <?php }
} ?>