<div class='text-center container min-vh-100 col-6 animated-on-scroll fade-in-fwd'>
    <div class='row h-100 align-items-center' id='profileContainer'>
        <div id='formRegister'>
            <form action='javascript:void(0);' method='post' enctype="multipart/form-data">
                <img src='/~S4633433/img/users/profile_pictures/profile-default.png'
                     alt='profile picture preview' id='profilepicPreview' class='mb-5'>
                <label for='firstname' class='visually-hidden'>Nome</label>
                <label for='lastname' class='visually-hidden'>Cognome</label>
                <div class="input-group input-group-lg mb-3">
                    <span class="input-group-text bg-dark text-white border-warning"><i class="far fa-address-card"></i></span>
                    <input name='firstname' type="text" class="form-control" placeholder="Nome"
                           aria-label="firstname" id='firstname'>
                    <input name='lastname' type="text" class="form-control" placeholder="Cognome"
                           aria-label="cognome" id='lastname'>
                </div>
                <label for='email' class='visually-hidden'>Email</label>
                <div class="input-group input-group-lg mb-3">
                    <span class="input-group-text bg-dark text-white border-warning"><i class="far fa-envelope"></i></span>
                    <input name='email' type="email" class="form-control" placeholder="Email"
                           aria-label="email" id='email'>
                </div>
                <label for='pass' class='visually-hidden'>Password</label>
                <div class="input-group input-group-lg mb-3">
                    <span class="input-group-text bg-dark text-white border-warning"><i class="fas fa-key"></i></span>
                    <input name='pass' type="password" class="form-control" placeholder="Password"
                           aria-label="password" id='pass'>
                </div>
                <label for='confirm' class='visually-hidden'>Conferma Password</label>
                <div class="input-group input-group-lg mb-3">
                    <span class="input-group-text bg-dark text-white border-warning"><i class="fas fa-key"></i></span>
                    <input name='confirm' type="password" class="form-control" placeholder="Conferma Password"
                           aria-label="conferma password" id='confirm'>
                </div>
                <label for='profilepic' class='visually-hidden'>Foto di profilo</label>
                <div class="input-group input-group-lg mb-3">
                    <span class="input-group-text bg-dark text-white border-warning">
                        <i class="fas fa-user"></i>
                    </span>
                    <input name='profilepic' type="file" class="form-control"
                           aria-label="foto di profilo" id='profilepic'>
                    <button class="btn btn-outline-danger bg-danger" type="button" id="profilepicCancel" disabled><i class="text-white fas fa-trash"></i></button>
                </div>
                <div class="input-group input-group-lg mb-3">
                    <input name='submit' type="submit" class="font-gamerstavern em-2 form-control btn btn-warning" value='Unisciti'
                           aria-label="conferma" id='registrationSubmit'>
                </div>
            </form>
        </div>
    </div>
</div>
