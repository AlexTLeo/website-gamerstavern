<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
if (isset($_SESSION['user_id'])) {
    $user_id = $_SESSION['user_id'];
}

// Loading as many comments as is specified by jQuery
if (isset($_POST['comments'])) {
    $comments = json_decode($_POST['comments'], true);

    if (intval($_POST['comments_count']) > 0) {
        for ($i = 0; $i < intval($_POST['comments_count']); $i++) {
            $comment = $comments[$i];
            $comment_id = $comment['comment_id'];
            $text = $comment['text'];
            $posted_date = strtotime($comment['posted_date']);
            $comment_poster_id = $comment['fk_user_id'];
            $name = $comment['name'];
            $surname = $comment['surname'];
            $posted_date = date('d-m-Y H:i', $posted_date);
            $profile_img_url = $comment['profile_image_url'];
            ?>
            <div class='text-white container comment-container comment-box card-banner col-4 px-2 my-2 w-75'>
                <div class='row h-auto'>
                    <?php if ((isset($user_id) && $user_id == $comment_poster_id) ||
                        isset($_SESSION['is_writer']) && $_SESSION['is_writer'] == 1) { ?>
                        <button class='btn btn-danger comment-delete-button w-auto'>
                            <i class="fas fa-trash"></i>
                            <input type='hidden' class="comment-id" value='<?php echo $comment_id ?>'>
                            <input type='hidden' class="comment-poster-id" value='<?php echo $comment_poster_id ?>'>
                        </button>
                    <?php } ?>
                    <span class='comment-header mt-3'>
                        <img src='img/users/profile_pictures/<?php echo($profile_img_url) ?>'
                             class="profilepic-preview-comment">
                        <div class='info-text d-inline'>
                            <span class='name-surname-text'>
                                <?php echo($name . ' ' . $surname . ',') ?>
                            </span>
                            <span class='date-text'>
                                <?php echo($posted_date) ?>
                            </span>
                        </div>
                    </span>
                    <div class='row comment-body-text ps-4 pe-2 pt-3 mb-0'>
                        <p>
                            <?php echo($text) ?>
                        </p>
                    </div>
                </div>
            </div>
        <?php } ?>
    <?php }
} ?>
