<div class='text-center container min-vh-100 col-6 animated-on-scroll fade-in-fwd'>
    <div class='row h-100 align-items-center'>
        <div id='formLogin'>
            <form action='javascript:void(0);' method='post' enctype="multipart/form-data">
                <label for='email' class='visually-hidden'>Email</label>
                <div class="input-group input-group-lg mb-3">
                    <span class="input-group-text"><i class="far fa-envelope"></i></span>
                    <input name='email' type="email" class="form-control" placeholder="Email"
                           aria-label="email" id='email'>
                </div>
                <label for='pass' class='visually-hidden'>Password</label>
                <div class="input-group input-group-lg mb-3">
                    <span class="input-group-text"><i class="fas fa-key"></i></span>
                    <input name='pass' type="password" class="form-control" placeholder="Password"
                           aria-label="password" id='pass'>
                </div>
                <div class="input-group input-group-lg mb-3">
                    <input name='submit' type="submit" class="font-gamerstavern em-2 form-control btn btn-success" value='Entra'
                           aria-label="accedi" id='loginSubmit'>
                </div>
            </form>
            <div class='text-white mb-3 d-flex align-items-center'>
                <div class='line'></div>
                <span class='font-gamerstavern px-4'>oppure</span>
                <div class='line'></div>
            </div>
            <div class="input-group input-group-lg mb-3">
                <button name='btn-register' type="submit" id='linkToRegisterPage'
                        class="font-gamerstavern em-3 form-control btn btn-warning"
                        aria-label="registrati">
                    Unisciti alla taverna
                </button>
            </div>
        </div>
    </div>
</div>

<!-- Modal -->
<div class="modal" tabindex="-1" id='loginModal'>
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id='loginModalTitle'></h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Chiudi"></button>
            </div>
            <div class="modal-body">
                <p id='loginModalBody'></p>
            </div>
        </div>
    </div>
</div>