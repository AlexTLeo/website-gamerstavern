<div class='text-center container min-vh-100 col-6 animated-on-scroll fade-in-fwd'>
    <div class='row h-100 align-items-center' id='profileContainer'>
        <div id='formUpdateProfile'>
            <form action='javascript:void(0);' method='post' class='align-self-center' enctype="multipart/form-data">
                <img alt='profile picture preview' id='profilepicPreviewUpdate' class='profilepic-preview-update mb-5'>
                <label for='firstname' class='visually-hidden'>Nome e Cognome</label>
                <label for='lastname' class='visually-hidden'>Cognome</label>
                <div class="input-group input-group-lg mb-3">
                    <span class="input-group-text bg-dark text-white border-warning"><i class="far fa-address-card"></i></span>
                    <input name='firstname' type="text" class="form-control" placeholder="Nome"
                        aria-label="firstname" id='firstname'>
                    <input name='lastname' type="text" class="form-control" placeholder="Cognome"
                        aria-label="cognome" id='lastname'>
                </div>
                <label for='email' class='visually-hidden'>Email</label>
                <div class="input-group input-group-lg mb-3">
                    <span class="input-group-text bg-dark text-white border-warning"><i class="far fa-envelope"></i></span>
                    <input name='email' type="email" class="form-control" placeholder="Email"
                           aria-label="email" id='email'>
                </div>
                <label for='profilepic' class='visually-hidden'>Foto di profilo</label>
                <div class="input-group input-group-lg mb-3">
                    <span class="input-group-text bg-dark text-white border-warning">
                        <i class="fas fa-user"></i>
                    </span>
                    <input name='profilepic' type="file" class="form-control"
                           aria-label="foto di profilo" id='profilepic'>
                    <button class="btn btn-outline-warning bg-warning btn-warning" type="button" id="profilepicCancel" disabled>
                        <i class="default-profile-image-button fas fa-undo-alt"></i>
                    </button>
                    <button type="button" class="btn btn-danger bg-danger btn-outline-danger default-profile-image-button" id='defaultImageSubmit'>
                        <i class="text-white fas fa-trash"></i>
                    </button>
                </div>
                <div class="input-group input-group-lg mb-3">
                    <button type="button" class="reset-button font-gamerstavern em-2 form-control btn btn-danger" id='resetButton'>Annulla modifiche</button>
                    <input name='submit' type="submit" class="font-gamerstavern em-2 form-control btn btn-warning" value='Modifica profilo'
                           aria-label="conferma" id='updateSubmit'>
            </form>
        </div>
    </div>
</div>
