<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
?>

<div class='container-fluid h-100' id='writerPanelContainer'>
    <div class='row text-center m-5' id='writerPanelContent'>
        <h1 class='font-gamerstavern'>Nuovo Articolo</h1>
        <form action='javascript:void(0);' method='post' class='align-self-center' enctype="multipart/form-data">
            <input type='hidden' id='author' value='<?php echo $_SESSION['name'] . ' ' . $_SESSION['surname'] ?>'>
            <label class='visually-hidden' for='title'>Titolo</label>
            <div class="input-group input-group-lg mb-3">
                <span class="input-group-text"><i class="fas fa-thumbtack"></i></span>
                <input name='title' type="text" class="form-control" placeholder="Titolo" id='title'>
            </div>
            <div class="input-group input-group-lg mb-3">
                <span class="input-group-text"><i class="fas fa-layer-group"></i></span>
                <select class="form-select form-select-lg" id='categorySelect' aria-label="#categorySelect">
                    <option value="" disabled><strong>--- Categorie ---</strong></option>
                    <option value="GamersTavern" selected>GamersTavern</option>
                    <option value="Videogiochi">Videogiochi</option>
                    <option value="Giochi da tavola">Giochi da tavola</option>
                    <option value="Tech">Tech</option>
                    <option value="Economia">Economia</option>
                </select>
            </div>
            <label for='bannerImage' class='visually-hidden'>Immagine Banner</label>
            <div class="input-group input-group-lg mb-3">
                <span class="input-group-text"><i class="fas fa-image"></i></span>
                <input name='bannerImage' type="file" class="form-control"
                       aria-label="foto banner" id='bannerImage'>
            </div>
            <label class='visually-hidden' for='articleEditor'>Editor Articolo</label>
            <textarea id='articleEditor' name='body'></textarea>
            <label class='visually-hidden' for='articleEditor'>Carica Nuovo Articolo</label>
            <div class="input-group input-group-lg mb-3">
                <input name='submit' type="submit" class="font-gamerstavern em-2 mt-5 form-control btn btn-success"
                       value='Carica Nuovo Articolo' aria-label="carica nuovo articolo" id='submitNewArticle'>
            </div>
        </form>
    </div>
</div>