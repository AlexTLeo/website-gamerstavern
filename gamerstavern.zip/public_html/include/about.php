<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
?>

<!-- Main Page -->
<div id='page-bg-container'>
    <img src='img/backgrounds/tavern-1.png' class='img-page-bg' alt='Picture of a medieval tavern'>
</div>

<div id='underConstruction' class='animated-on-scroll slide-in-right-far vh-100 container-fluid' style='background: rgba(255, 255, 255, 0.2); pointer-events: none'>
    <img src='img/under-construction.png' class='' alt='Nastro giallo nero di costruzione'
         aria-label='Pagina attualmente in lavorazione'
         style='width: 100%; transform: scale(1.1) translateX(2em); pointer-events: none; object-fit: cover'>
</div>