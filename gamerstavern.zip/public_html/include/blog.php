<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
?>

<!-- Main Page -->
<div id='page-bg-container'>
    <img src='img/backgrounds/tavern-1.png' class='img-page-bg' alt='Picture of a wooden table with a controller on it'>
</div>

<div class='common-main blog-main text-center container min-vh-100 p-3 mx-auto'>
    <div class='row h-100 w-100 align-items-center'>
        <span>
            <i class="fas fa-blog animated-on-scroll px-4"></i><br>
            <span class='animated-on-scroll'>News e storie sul mondo videoludico</span>
        </span>
    </div>

    <div class='common-main-arrow-container'>
        <a class='text-decoration-none text-white' href='#anchor-to-content'>
            <i class="common-main-arrow fas fa-angle-double-down"></i>
        </a>
    </div>
</div>


<!-- Content -->
<div class='parallax-on-scroll blog-articles-container'>

    <div class='container-fluid p-0 blog-articles'>
        <!-- This div fixes weird bug with banner being detected in viewport on load -->
        <div class='row' style='height: 0.1px;'></div>

        <!-- Banner -->
        <div class='animated-on-scroll slide-in-right-far row text-center blog-banner-container'>
            <a id='anchor-to-content'></a>
            <?php
            // If user is not a writer
            if (!isset($_SESSION['is_writer'])) { ?>
                <header class='d-flex flex-column justify-content-center'>
                    <h1>Ultimi Articoli</h1>
                    <div>
                        <p>
                            Scopri le ultime notizie del mondo videoludico<br>
                            <a href='#anchor-to-article-search'>Esplora i nostri articoli</a>
                        </p>
                    </div>
                </header>

                <?php
                // If user is a writer
            } else { ?>
                <!-- Writer Banner -->
                <header class='blog-writer-banner d-flex flex-column justify-content-center'>
                    <h1>Bentornato,
                        <span class='special-red'>
                        <?php echo $_SESSION['name'] . ' ' . $_SESSION['surname'] ?>
                        </span>
                        !
                    </h1>
                    <div class='mt-3'>
                        <p>
                            <button class='btn btn-warning' id='buttonWriteArticle'>
                                Scrivi un nuovo articolo <i class="ps-2 fas fa-feather-alt"></i>
                            </button>
                        </p>
                    </div>
                </header>
            <?php } ?>
        </div>
    </div>

    <!-- Search for articles -->
    <a id='anchor-to-article-search'></a>
    <div id='blogContentContainer' class='h-100'>
        <div class='container-fluid p-0 article-container'>
            <div class='row'>
                <div class='d-flex flex-row animated-on-scroll slide-in-left' id='searchContainer'>
                    <div class="card flex-fill h-100">
                        <h3 class="heading mt-5 text-center">Cerchi qualcosa in particolare?</h3>
                        <div class="d-flex align-self-center justify-content-center" id='articleSearchBox'>
                            <div class="search">
                                <input type="text" class="search-input" placeholder="Cerca..." name=""
                                       id='articleSearch'>
                                <button class="search-icon btn" id='articleSearchButton'>
                                    <i class="fa fa-search"></i>
                                </button>
                            </div>
                        </div>
                        <div class="mt-4 g-1 mx-5 px-5 mb-5 d-flex flex-row justify-content-center">
                            <span class='article-search-category-box px-4 text-center flex-fill'>
                                <a class='text-decoration-none w-100 category-button' href='javascript:void(0);'>
                                    <i class="fas fa-gamepad"></i>
                                    <footer class='category-name'>Videogiochi</footer>
                                </a>
                            </span>
                            <span class='article-search-category-box px-4 text-center flex-fill'>
                                <a class='text-decoration-none w-100 category-button' href='javascript:void(0);'>
                                    <i class="fas fa-dice-d20"></i>
                                    <footer class='category-name'>Giochi da tavola</footer>
                                </a>
                            </span>
                            <span class='article-search-category-box px-4 text-center flex-fill'>
                                <a class='text-decoration-none w-100 category-button' href='javascript:void(0);'>
                                    <img src='img/logo-white-black.png' style='filter: invert(100%)'>
                                    <footer class='category-name'>GamersTavern</footer>
                                </a>
                            </span>
                            <span class='article-search-category-box px-4 text-center flex-fill'>
                                <a class='text-decoration-none w-100 category-button' href='javascript:void(0);'>
                                    <i class="fas fa-microchip"></i>
                                    <footer class='category-name'>Tech</footer>
                                </a>
                            </span>
                            <span class='article-search-category-box px-4 text-center flex-fill'>
                                <a class='text-decoration-none w-100 category-button' href='javascript:void(0);'>
                                    <i class="fas fa-chart-pie"></i>
                                    <footer class='category-name'>Economia</footer>
                                </a>
                            </span>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class='container-fluid p-0' id='articlePreviewsContainer'>
            <!-- Articles loaded in dynamically -->
        </div>

        <!-- Navigation -->
        <div class='container-fluid p-0'>
            <div class='row d-flex bg-navigation'>
                <nav aria-label="Article Navigation" class='d-flex justify-content-center'>
                    <ul class="pagination m-0 navigate-articles">
                        <li class="page-item">
                            <a class="page-link px-5 mx-5 border-0 text-black-50 bg-transparent shadow-none text-decoration-none"
                               href="javascript:void(0)" aria-label="Previous" id='articlePrevious'>
                                <span class='special-red font-gamerstavern'><i class="px-5 fas fa-long-arrow-alt-left"></i> Precedente</span>
                            </a>
                        </li>
                        <li class="page-item">
                            <a class="page-link px-5 mx-5 border-0 text-black-50 bg-transparent shadow-none text-decoration-none"
                               href="javascript:void(0);" aria-label="Next" id='articleNext'>
                                <span class='special-red font-gamerstavern'>Prossimo <i class="px-5 fas fa-long-arrow-alt-right"></i></span>
                            </a>
                        </li>
                    </ul>
                </nav>
            </div>
        </div>
    </div>
</div>

