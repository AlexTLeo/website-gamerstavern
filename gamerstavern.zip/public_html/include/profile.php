<?php
if (session_status() == PHP_SESSION_NONE) {
    session_start();
} ?>

<!-- Main Page -->
<div id='page-bg-container'>
    <img src='img/backgrounds/tavern-1.png' class='img-page-bg' alt='Picture of a medieval tavern'>
</div>

<div class='container animated-on-scroll fade-in-fwd'>
    <div id='profilePageContent' class='row'>
        <?php
        if (!isset($_SESSION['logged_in'])) {
            // Javascript listeners dynamically update to registration/login/profile when needed
            include('components/login_form.php');
        } else {
            include('components/profile_form.php');
        }
        ?>
    </div>
</div>